
function basic_form_expand(){
	$('#basic_form').slideDown('slow');
	$('#basic_info').slideUp('fast');
}


function basic_form_contract(){
	$('#basic_info').slideDown('slow');
	$('#basic_form').slideUp('fast');

}

function keywords_form_expand(){
	category_info_get();
	$('#keywords_form').slideDown('slow');
	$('#keywords_info').slideUp('fast');
}

function keywords_form_contract(){
	$('#keywords_info').slideDown('slow');
	$('#keywords_form').slideUp('fast');

}

function investments_form_expand(){
	$('#investments_form').slideDown('slow');
	$('#investments_info').slideUp('fast');
}


function investments_form_contract(){
	$('#investments_info').slideDown('slow');
	$('#investments_form').slideUp('fast');

}


function people_form_expand(){
	$('#people_form').slideDown('slow');
	$('#people_info').slideUp('fast');
}

function people_form_contract(){
	$('#people_info').slideDown('slow');
	$('#people_form').slideUp('fast');

}

function partnerships_form_expand(){
	$('#partnerships_form').slideDown('slow');
	$('#partnerships_info').slideUp('fast');
}



function partnerships_form_contract(){
	$('#partnerships_info').slideDown('slow');
	$('#partnerships_form').slideUp('fast');

}

function products_form_expand(){

	$('#products_form').slideDown('slow');
	$('#products_info').slideUp('fast');
}



function products_form_contract(){
	$('#products_info').slideDown('slow');
	$('#products_form').slideUp('fast');

}

function internal_form_expand(){

	$('#internal_form').slideDown('slow');
	$('#internal_info').slideUp('fast');
}




function internal_form_contract(){
	$('#internal_info').slideDown('slow');
	$('#internal_form').slideUp('fast');

}

function singleVideos_form_expand(){
	singleVideo_info_get();
	$('#singleVideo_form').slideDown('slow');
	$('#singleVideo_info').slideUp('fast');
}

function singleVideos_form_contract(){
	$('#keywords_info').slideDown('slow');
	$('#keywords_form').slideUp('fast');

}


